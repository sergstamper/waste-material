function Recommendation() {
  return (
    <div>
      <h1>Recommendation</h1>
    </div>
  );
}

export default Recommendation;